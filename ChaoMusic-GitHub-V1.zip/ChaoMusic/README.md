# ChaoMusic V1 — Android starter

Paket aplikasi: `com.chaomusic.app`

## Fitur starter
- Antarmuka Android native Kotlin dengan nuansa biru Liquid Glass.
- Navigasi Home, Search, Library, dan Profile.
- Pemilihan dan pemutaran file audio lokal dari perangkat.
- Pemilih gambar untuk personalisasi background (fondasi awal).
- Guest mode sebagai tampilan awal.

## Belum diimplementasikan
Streaming online, katalog lagu Indonesia/internasional, login/register, sinkronisasi playlist, lirik, dan unduhan offline belum aktif. Fitur itu membutuhkan integrasi penyedia katalog/API, autentikasi, serta hak pemutaran/unduh sesuai lisensi.

## Build APK lewat GitHub dari HP
1. Buat repository baru di GitHub, misalnya `ChaoMusic`.
2. Upload seluruh isi folder proyek ini ke repository (termasuk folder `.github/workflows`).
3. Pastikan branch utamanya bernama `main`.
4. Buka tab **Actions**. Jika diminta, izinkan GitHub Actions.
5. Workflow **Build ChaoMusic APK** akan berjalan setelah upload; bisa juga dijalankan lewat **Run workflow**.
6. Setelah selesai, buka proses workflow yang berhasil, lalu unduh artifact **ChaoMusic-debug-apk**.
7. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`.

## Build config
Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35, minSdk 26. Workflow menggunakan JDK 17 dan Gradle 8.9.
