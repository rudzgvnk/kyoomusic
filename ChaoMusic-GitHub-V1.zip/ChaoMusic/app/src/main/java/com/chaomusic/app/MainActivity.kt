package com.chaomusic.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var nowPlaying: TextView
    private var player: MediaPlayer? = null
    private var currentUri: Uri? = null
    private var isPlaying = false
    private var selectedBackground = 0

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            currentUri = it
            playUri(it)
            showHome()
        }
    }

    private val pickBackground = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            root.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(7, 18, 48), Color.rgb(18, 76, 140), Color.rgb(5, 13, 35))
            )
            Toast.makeText(this, "Background dipilih. Kustom wallpaper penuh akan disempurnakan di versi berikutnya.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 15, 37)
        window.navigationBarColor = Color.rgb(7, 15, 37)
        buildShell()
        showHome()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5, 13, 34), Color.rgb(13, 49, 94), Color.rgb(5, 12, 31))
            )
        }
        setContentView(root)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "ChaoMusic"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        val spacer = View(this)
        val settings = TextView(this).apply {
            text = "⚙"
            textSize = 25f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener { showSettings() }
        }
        header.addView(brand)
        header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(settings)
        root.addView(header)

        val tagline = TextView(this).apply {
            text = "Your Music, Your World."
            textSize = 12f
            setTextColor(Color.rgb(160, 205, 255))
            setPadding(0, dp(2), 0, dp(12))
        }
        root.addView(tagline)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        nowPlaying = TextView(this).apply {
            text = "♫  Belum ada musik diputar"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = glass()
            setOnClickListener { togglePlayback() }
        }
        root.addView(nowPlaying, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = glass()
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        listOf("⌂\nHome", "⌕\nSearch", "♫\nLibrary", "◉\nProfile").forEachIndexed { index, label ->
            val item = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 12f
                setTextColor(Color.WHITE)
                setPadding(dp(5), dp(4), dp(5), dp(4))
                setOnClickListener {
                    when (index) {
                        0 -> showHome()
                        1 -> showSearch()
                        2 -> showLibrary()
                        else -> showProfile()
                    }
                }
            }
            nav.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
    }

    private fun showHome() {
        content.removeAllViews()
        title("Good evening ✨")
        subtitle("Temukan musik yang menemani harimu.")
        val hero = TextView(this).apply {
            text = "BLUE VIBES\\n\\nPutar musik favoritmu\\ndan nikmati suasananya."
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(30), dp(18), dp(30))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(25, 113, 207), Color.rgb(28, 57, 126), Color.rgb(92, 169, 255))
            ).apply { cornerRadius = dp(25).toFloat() }
        }
        content.addView(hero, marginParams(bottom = 18))
        title("Mulai mendengarkan")
        actionCard("＋  Pilih musik dari HP", "Putar file audio yang tersimpan di perangkat") {
            pickAudio.launch(arrayOf("audio/*"))
        }
        actionCard("⌕  Cari musik", "Cari lagu, artis, atau album") { showSearch() }
        title("Pilihan untukmu")
        subtitle("Katalog streaming online akan dihubungkan pada tahap integrasi API.")
        actionCard("🌊  Blue mood", "Playlist pilihan • Segera hadir") { }
    }

    private fun showSearch() {
        content.removeAllViews()
        title("Search")
        subtitle("Cari judul lagu, artis, atau album.")
        val input = EditText(this).apply {
            hint = "Contoh: Tulus, NIKI, K-pop..."
            setHintTextColor(Color.rgb(160, 190, 225))
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = glass()
        }
        content.addView(input, marginParams(bottom = 12))
        actionCard("Indonesia 🇮🇩", "Musik dan artis Indonesia") { input.setText("Indonesia") }
        actionCard("International 🌎", "Musik dari seluruh dunia") { input.setText("International") }
        actionCard("K-pop / J-pop", "Jelajahi musik Korea dan Jepang") { input.setText("K-pop") }
        subtitle("Pencarian online aktif setelah API katalog musik diintegrasikan.")
    }

    private fun showLibrary() {
        content.removeAllViews()
        title("Your Library")
        subtitle("Koleksi musikmu ada di satu tempat.")
        actionCard("♫  Musik dari perangkat", "Pilih dan putar file audio lokal") {
            pickAudio.launch(arrayOf("audio/*"))
        }
        actionCard("♡  Favorites", "Lagu favorit akan tersedia setelah penyimpanan koleksi ditambahkan") { }
        actionCard("▤  Playlists", "Buat playlist pribadi pada versi berikutnya") { }
    }

    private fun showProfile() {
        content.removeAllViews()
        title("Profile")
        subtitle("Kamu sedang menggunakan ChaoMusic sebagai Guest.")
        actionCard("Masuk / Daftar", "Sinkronisasi playlist dan favorit online • Segera hadir") { }
        actionCard("Pengaturan tampilan", "Atur wallpaper dan nuansa aplikasi") { showSettings() }
    }

    private fun showSettings() {
        content.removeAllViews()
        title("Appearance")
        subtitle("Personalisasi tampilan ChaoMusic.")
        actionCard("▧  Ganti background", "Pilih gambar dari galeri") {
            pickBackground.launch(arrayOf("image/*"))
        }
        actionCard("💙  Blue Glass", "Tema biru Liquid Glass aktif") { }
        actionCard("Reset tampilan", "Kembali ke tampilan biru bawaan") {
            root.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5, 13, 34), Color.rgb(13, 49, 94), Color.rgb(5, 12, 31))
            )
        }
    }

    private fun playUri(uri: Uri) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener {
                    it.start()
                    isPlaying = true
                    nowPlaying.text = "♫  Sedang diputar  •  Ketuk untuk pause"
                }
                setOnCompletionListener { isPlaying = false; nowPlaying.text = "♫  Pemutaran selesai" }
                prepareAsync()
            }
            nowPlaying.text = "♫  Memuat musik..."
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa memutar file ini.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun togglePlayback() {
        val p = player ?: run {
            Toast.makeText(this, "Pilih musik dari HP terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        if (isPlaying) {
            p.pause()
            isPlaying = false
            nowPlaying.text = "▶  Dijeda • Ketuk untuk lanjut"
        } else {
            p.start()
            isPlaying = true
            nowPlaying.text = "♫  Sedang diputar • Ketuk untuk pause"
        }
    }

    private fun title(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, dp(5))
        })
    }

    private fun subtitle(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.rgb(173, 205, 239))
            setPadding(0, 0, 0, dp(12))
        })
    }

    private fun actionCard(title: String, detail: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(13), dp(16), dp(13))
            background = glass()
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        box.addView(TextView(this).apply {
            text = detail
            textSize = 12f
            setTextColor(Color.rgb(177, 207, 241))
            setPadding(0, dp(4), 0, 0)
        })
        content.addView(box, marginParams(bottom = 10))
    }

    private fun glass(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.argb(75, 113, 177, 245))
        setStroke(dp(1), Color.argb(105, 180, 220, 255))
        cornerRadius = dp(20).toFloat()
    }

    private fun marginParams(bottom: Int = 0) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(bottom)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
